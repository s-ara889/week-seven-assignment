import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: HomePage(),
    );
  }
}



class HomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Basic Layout"),
      ),
      body: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          children: [


            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
            Icon(Icons.ac_unit),
                Text("My App"),
                Icon(Icons.settings),
              ],
            ),

            SizedBox(height: 20),


            Container(
              padding: EdgeInsets.all(16),
              color: Colors.grey[200],
              child: Column(
                children: [

                  CircleAvatar(
                    radius: 40,
                    child: Icon(Icons.person),
                  ),

                  SizedBox(height: 10),

                  Text(
                    "Sara Walid",
                    style: TextStyle(fontSize: 18),
                  ),

                  Text("Flutter Developer"),

                  SizedBox(height: 10),

                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      Icon(Icons.facebook),
                      Icon(Icons.telegram),
                      Icon(Icons.email),
                    ],
                  ),
                ],
              ),
            ),

            SizedBox(height: 20),


            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => MainPage()),
                );
              },
              child: Text("Next Page"),
            ),
          ],
        ),
      ),
    );
  }
}



class MainPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Advanced Layout"),
      ),
      body: Column(
        children: [


          Stack(
            children: [

              Container(
                height: 150,
                width: double.infinity,
                color: Colors.blue,
              ),

              Positioned(
                top: 50,
                left: 20,
                child: Text(
                  "Welcome to Flutter",
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 20,
                  ),
                ),
              ),
            ],
          ),


          Expanded(
            child: ListView.builder(
              itemCount: 10,
              itemBuilder: (context, index) {
                return Container(
                  margin: EdgeInsets.all(8),
                  padding: EdgeInsets.all(16),
                  color: Colors.blue[200],
                  child: Row(
                    children: [
                      Icon(Icons.star),
                      SizedBox(width: 10),
                      Text("Item ${index + 1}"),
                    ],
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}